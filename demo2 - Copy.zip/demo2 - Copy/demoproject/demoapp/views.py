from django.shortcuts import render
from .models import Place,Team,Destination

# Create your views here.
def Home(req):
    data=Place.objects.all()
    name=Team.objects.all()
    return render(req,"index.html",{'data':data,'name':name})

def About(req):
    return render(req,"about.html")

def Dest(req):
    destin=Destination.objects.all()
    return render(req,"destinations.html",{'destin':destin})